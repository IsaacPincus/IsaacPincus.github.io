function curvesViewer(t0, t1, x, y, z, xd, yd, zd)
    % Simple figure-based parametric curve viewer
    % Usage: curvesViewer(t0, t1, @(t)x_func, @(t)y_func, @(t)z_func)
    %    or: curvesViewer(t0, t1, @(t)x, @(t)y, @(t)z, @(t)xd, @(t)yd, @(t)zd)

    % Developed by Isaac Pincus, 2025
    
    if nargin == 5
        velocityOn = false;
    elseif nargin == 8
        velocityOn = true;
    else
        error('Need 5 or 8 input arguments');
    end
    
    % Create figure
    fig = figure('Name', 'Parametrised Curves', ...
                 'Position', [100 100 640 480]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.13 0.3 0.75 0.65]);
    hold(ax, 'on');
    grid(ax, 'on');
    title(ax, 'Parametrised Curve', 'Interpreter', 'latex');
    xlabel(ax, '$x$', 'Interpreter', 'latex');
    ylabel(ax, '$y$', 'Interpreter', 'latex');
    zlabel(ax, '$z$', 'Interpreter', 'latex');
    view(ax, [49.56 19.67]);
    
    % Plot full curve
    tt = linspace(t0, t1, 1000);
    plot3(ax, x(tt), y(tt), z(tt), 'b-', 'LineWidth', 1.5);
    
    % Create graphics objects for updating (use quiver3 instead of surf)
    t = t0;
    xv = x(t); yv = y(t); zv = z(t);
    
    % Position arrow (green)
    hPos = quiver3(ax, 0, 0, 0, xv, yv, zv, 0, ...
                   'LineWidth', 2, 'Color', 'g', 'MaxHeadSize', 0.5);
    
    % Position text
    str = sprintf('$\\vec{\\varphi}(%0.1f) = (%0.1f, %0.1f, %0.1f)$', ...
                  t, xv, yv, zv);
    hTxt = text(ax, xv+0.1, yv+0.1, zv+0.1, str, ...
                'Interpreter', 'latex', 'FontSize', 14);
    
    % Velocity arrow and text (if applicable)
    if velocityOn
        hVel = quiver3(ax, xv, yv, zv, xd(t), yd(t), zd(t), 0, ...
                       'LineWidth', 2, 'Color', 'r', 'MaxHeadSize', 0.5);
        
        str = sprintf('$\\frac{\\partial \\vec{\\varphi}}{\\partial t}(%0.1f) = (%0.1f, %0.1f, %0.1f)$', ...
                      t, xd(t), yd(t), zd(t));
        hTxtd = text(ax, xv+xd(t)+0.1, yv+yd(t)+0.1, zv+zd(t)+0.1, str, ...
                     'Interpreter', 'latex', 'FontSize', 14);
        
        % Set axis limits including velocity
        xlim(ax, [min([0, x(tt)+xd(tt)])-0.1, max(x(tt)+xd(tt))+0.1]);
        ylim(ax, [min([0, y(tt)+yd(tt)])-0.1, max(y(tt)+yd(tt))+0.1]);
        zlim(ax, [min([0, z(tt)+zd(tt)])-0.1, max(z(tt)+zd(tt))+0.1]);
    else
        xlim(ax, [min([0, x(tt)])-0.1, max(x(tt))+0.1]);
        ylim(ax, [min([0, y(tt)])-0.1, max(y(tt))+0.1]);
        zlim(ax, [min([0, z(tt)])-0.1, max(z(tt))+0.1]);
        axis(ax, 'equal');
    end
    
    % Create slider
    slider = uicontrol('Parent', fig, 'Style', 'slider', ...
                       'Units', 'normalized', ...
                       'Position', [0.4 0.1 0.3 0.05], ...
                       'Min', t0, 'Max', t1, 'Value', t0, ...
                       'Callback', @sliderCallback);
    
    % Add listener for continuous update while dragging
    addlistener(slider, 'ContinuousValueChange', @(src,evt) sliderCallback(src, evt));
    
    % Slider label
    htValue = uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.35 0.095 0.04 0.05], ...
              'String', sprintf('t = %.4g', t0), 'FontSize', 12, ...
              'HorizontalAlignment', 'right');
    
    % Slider callback function
    function sliderCallback(src, ~)
        t = src.Value;
        xv = x(t); yv = y(t); zv = z(t);

        % update text
        set(htValue, 'String', sprintf('t = %.4g', t));
        
        % Update position arrow
        set(hPos, 'XData', 0, 'YData', 0, 'ZData', 0, ...
                  'UData', xv, 'VData', yv, 'WData', zv);
        
        % Update position text
        str = sprintf('$\\vec{\\varphi}(%0.1f) = (%0.1f, %0.1f, %0.1f)$', ...
                      t, xv, yv, zv);
        set(hTxt, 'String', str, 'Position', [xv+0.1, yv+0.1, zv+0.1]);
        
        % Update velocity if needed
        if velocityOn
            set(hVel, 'XData', xv, 'YData', yv, 'ZData', zv, ...
                      'UData', xd(t), 'VData', yd(t), 'WData', zd(t));
            
            str = sprintf('$\\frac{\\partial \\vec{\\varphi}}{\\partial t}(%0.1f) = (%0.1f, %0.1f, %0.1f)$', ...
                          t, xd(t), yd(t), zd(t));
            set(hTxtd, 'String', str, ...
                'Position', [xv+xd(t)+0.1, yv+yd(t)+0.1, zv+zd(t)+0.1]);
        end
    end
end