clear variables;
close all;

% calculate a double integral given by the function:
fxy = @(x, y) x.*sin(x).*cos(y);
% make sure to use .^, .* etc to do component-wise exponentials and
% multiplications, rather than matrix multiplication

% domain, in this case it's just a rectangle
x0 = 0;
x1 = 2*pi;
y0 = 0;
y1 = 2*pi;

x = linspace(x0,x1,100);
y = linspace(y0,y1,100);
[X,Y] = meshgrid(x,y);

% z-values given function
Z = fxy(X,Y);

% % this section creates the vertical patches to show integration in the
% % x-direction. 
% yv = linspace(y0,y1,10);
% for ii = 1:length(yv)
%     xv = linspace(x0,x1,10);
%     zv = fxy(xv, yv(ii));
%     % we define the x, y, z coordinates of the points making up the patches
%     % we want to plot for each y-slice.
%     xp(:,ii) = [xv(1), xv, xv(end)]';
%     yp(:,ii) = ones(size(xp(:,ii)))*yv(ii);
%     zp(:,ii) = [0, zv, 0]';
% end

% plot everything
figure();
hold on
% surf(X,Y,Z, 'FaceAlpha',1, 'EdgeColor','none')
surf(X,Y,Z)
% surf(X,Y,zeros(size(Z)), 'FaceAlpha',0.2, 'EdgeColor','none', 'FaceColor','k')
% comment out the following line to remove the patches
% patch(xp, yp, zp, 'r', 'FaceAlpha', 0.5);
xlabel('$x$', 'Interpreter','latex', 'FontSize',24);
ylabel('$y$', 'Interpreter','latex', 'FontSize',24);
zlabel('$z$', 'Interpreter','latex', 'FontSize',24);
box on
xlim([x0,x1])
ylim([y0,y1])
view(-30,30)

% Developed by Isaac Pincus, 2025



















