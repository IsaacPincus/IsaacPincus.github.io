function surfacesViewer(u0, u1, v0, v1, x, y, z)
    % Simple figure-based parametric surface viewer
    % Usage: surfacesViewer(u0, u1, v0, v1, @(u,v)x_func, @(u,v)y_func, @(u,v)z_func)

    % Developed by Isaac Pincus, 2025
    
    % Create figure
    fig = figure('Name', 'Parametrised Surfaces', ...
                 'Position', [100 100 640 580]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.13 0.42 0.75 0.53]);
    hold(ax, 'on');
    grid(ax, 'on');
    title(ax, 'Parametrised Surface', 'Interpreter', 'latex');
    xlabel(ax, '$x$', 'Interpreter', 'latex');
    ylabel(ax, '$y$', 'Interpreter', 'latex');
    zlabel(ax, '$z$', 'Interpreter', 'latex');
    view(ax, [49.56 19.67]);
    
    % Plot full surface
    fsurf(ax, x, y, z, [u0, u1, v0, v1], ...
          'FaceAlpha', 0.3, 'FaceColor', 'b', 'EdgeColor', 'none');
    
    % Create graphics objects for updating
    u = u0;
    v = v0;
    xv = x(u, v);
    yv = y(u, v);
    zv = z(u, v);
    
    % Position arrow (green) - use quiver3 instead of surf
    hPos = quiver3(ax, 0, 0, 0, xv, yv, zv, 0, ...
                   'LineWidth', 2, 'Color', 'g', 'MaxHeadSize', 0.5);
    
    % Position text
    str = sprintf('$\\vec{\\psi}(%0.1f, %0.1f) = (%0.1f, %0.1f, %0.1f)$', ...
                  u, v, xv, yv, zv);
    hTxt = text(ax, xv+0.1, yv+0.1, zv+0.1, str, ...
                'Interpreter', 'latex', 'FontSize', 14);
    
    % Add lighting
    camlight(ax);
    lighting(ax, 'gouraud');
    
    % Create u slider
    uSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.4 0.15 0.3 0.04], ...
                        'Min', u0, 'Max', u1, 'Value', u0, ...
                        'Callback', @uSliderCallback);
    
    % Add listener for continuous update while dragging u slider
    addlistener(uSlider, 'ContinuousValueChange', @(src,evt) uSliderCallback(src, evt));
    
    % u slider label
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.33 0.145 0.06 0.04], ...
              'String', 'u =', 'FontSize', 12, ...
              'HorizontalAlignment', 'right');
    
    % u slider value display
    hUValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.71 0.145 0.08 0.04], ...
                        'String', sprintf('%.2f', u0), 'FontSize', 12, ...
                        'HorizontalAlignment', 'left');
    
    % Create v slider
    vSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.4 0.3 0.3 0.04], ...
                        'Min', v0, 'Max', v1, 'Value', v0, ...
                        'Callback', @vSliderCallback);
    
    % Add listener for continuous update while dragging v slider
    addlistener(vSlider, 'ContinuousValueChange', @(src,evt) vSliderCallback(src, evt));
    
    % v slider label
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.33 0.295 0.06 0.04], ...
              'String', 'v =', 'FontSize', 12, ...
              'HorizontalAlignment', 'right');
    
    % v slider value display
    hVValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.71 0.295 0.08 0.04], ...
                        'String', sprintf('%.2f', v0), 'FontSize', 12, ...
                        'HorizontalAlignment', 'left');
    
    % u slider callback function
    function uSliderCallback(src, ~)
        u = src.Value;
        set(hUValue, 'String', sprintf('%.2f', u));
        updatePlot();
    end
    
    % v slider callback function
    function vSliderCallback(src, ~)
        v = src.Value;
        set(hVValue, 'String', sprintf('%.2f', v));
        updatePlot();
    end
    
    % Update plot function
    function updatePlot()
        xv = x(u, v);
        yv = y(u, v);
        zv = z(u, v);
        
        % Update position arrow
        set(hPos, 'XData', 0, 'YData', 0, 'ZData', 0, ...
                  'UData', xv, 'VData', yv, 'WData', zv);
        
        % Update position text
        str = sprintf('$\\vec{\\psi}(%0.1f, %0.1f) = (%0.1f, %0.1f, %0.1f)$', ...
                      u, v, xv, yv, zv);
        set(hTxt, 'String', str, 'Position', [xv+0.1, yv+0.1, zv+0.1]);
    end
end