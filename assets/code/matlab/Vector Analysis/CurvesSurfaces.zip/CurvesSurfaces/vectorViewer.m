function vectorViewer(v)
    % Simple 3D vector viewer with sliders
    % Usage: vectorViewer()
    %    or: vectorViewer([vx, vy, vz])

    % Developed by Isaac Pincus, 2025
    
    % Set initial vector
    if nargin < 1
        vx = 1;
        vy = 1;
        vz = 1;
    else
        vx = v(1);
        vy = v(2);
        vz = v(3);
    end
    
    % minval = -5;
    maxVal = max([abs(vx), abs(vy), abs(vz), 1]) * 2;
    
    % Create figure
    fig = figure('Name', 'Vector Viewer', ...
                 'Position', [100 100 700 700]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.13 0.35 0.75 0.6]);
    hold(ax, 'on');
    grid(ax, 'on');
    axis(ax, 'equal');
    title(ax, 'Vector Visualization', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [49.56 19.67]);
    
    % Create vector arrow
    hVec = quiver3(ax, 0, 0, 0, vx, vy, vz, 0, ...
                   'LineWidth', 3, 'Color', 'b', 'MaxHeadSize', 0.5);
    
    % Create origin marker
    plot3(ax, 0, 0, 0, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
    
    % Create text label
    str = sprintf('$\\mathbf{v} = (%.2f, %.2f, %.2f)$', vx, vy, vz);
    magnitude = sqrt(vx^2 + vy^2 + vz^2);
    magStr = sprintf('$|\\mathbf{v}| = %.3f$', magnitude);
    
    hTxt = text(ax, vx*1.1, vy*1.1, vz*1.1, {str, magStr}, ...
                'Interpreter', 'latex', 'FontSize', 12, ...
                'BackgroundColor', 'white', 'EdgeColor', 'black');
    
    % Set initial axis limits
    % updateAxisLimits();
    xlim(ax, [-maxVal, maxVal]);
    ylim(ax, [-maxVal, maxVal]);
    zlim(ax, [-maxVal, maxVal]);
    
    % Add lighting
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    % Create vx slider
    vxSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                         'Units', 'normalized', ...
                         'Position', [0.25 0.22 0.5 0.03], ...
                         'Min', -maxVal, 'Max', maxVal, 'Value', vx, ...
                         'Callback', @vxSliderCallback);
    addlistener(vxSlider, 'ContinuousValueChange', @(src,evt) vxSliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.13 0.215 0.1 0.03], ...
              'String', 'vx =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hVxValue = uicontrol('Parent', fig, 'Style', 'text', ...
                         'Units', 'normalized', ...
                         'Position', [0.76 0.215 0.1 0.03], ...
                         'String', sprintf('%.2f', vx), 'FontSize', 11, ...
                         'HorizontalAlignment', 'left');
    
    % Create vy slider
    vySlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                         'Units', 'normalized', ...
                         'Position', [0.25 0.15 0.5 0.03], ...
                         'Min', -maxVal, 'Max', maxVal, 'Value', vy, ...
                         'Callback', @vySliderCallback);
    addlistener(vySlider, 'ContinuousValueChange', @(src,evt) vySliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.13 0.145 0.1 0.03], ...
              'String', 'vy =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hVyValue = uicontrol('Parent', fig, 'Style', 'text', ...
                         'Units', 'normalized', ...
                         'Position', [0.76 0.145 0.1 0.03], ...
                         'String', sprintf('%.2f', vy), 'FontSize', 11, ...
                         'HorizontalAlignment', 'left');
    
    % Create vz slider
    vzSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                         'Units', 'normalized', ...
                         'Position', [0.25 0.08 0.5 0.03], ...
                         'Min', -maxVal, 'Max', maxVal, 'Value', vz, ...
                         'Callback', @vzSliderCallback);
    addlistener(vzSlider, 'ContinuousValueChange', @(src,evt) vzSliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.13 0.075 0.1 0.03], ...
              'String', 'vz =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hVzValue = uicontrol('Parent', fig, 'Style', 'text', ...
                         'Units', 'normalized', ...
                         'Position', [0.76 0.075 0.1 0.03], ...
                         'String', sprintf('%.2f', vz), 'FontSize', 11, ...
                         'HorizontalAlignment', 'left');
    
    % Slider callback functions
    function vxSliderCallback(src, ~)
        vx = src.Value;
        set(hVxValue, 'String', sprintf('%.2f', vx));
        updatePlot();
    end
    
    function vySliderCallback(src, ~)
        vy = src.Value;
        set(hVyValue, 'String', sprintf('%.2f', vy));
        updatePlot();
    end
    
    function vzSliderCallback(src, ~)
        vz = src.Value;
        set(hVzValue, 'String', sprintf('%.2f', vz));
        updatePlot();
    end
    
    % Update plot function
    function updatePlot()
        % Update vector
        set(hVec, 'UData', vx, 'VData', vy, 'WData', vz);
        
        % Update text
        str = sprintf('$\\mathbf{v} = (%.2f, %.2f, %.2f)$', vx, vy, vz);
        magnitude = sqrt(vx^2 + vy^2 + vz^2);
        magStr = sprintf('$|\\mathbf{v}| = %.3f$', magnitude);
        
        set(hTxt, 'String', {str, magStr}, ...
                  'Position', [vx*1.1, vy*1.1, vz*1.1]);
        
        % % Update axis limits
        % updateAxisLimits();
    end
    
    % % Update axis limits based on vector
    % function updateAxisLimits()
    %     maxVal = max([abs(vx), abs(vy), abs(vz), 1]) * 1.3;
    %     xlim(ax, [-maxVal, maxVal]);
    %     ylim(ax, [-maxVal, maxVal]);
    %     zlim(ax, [-maxVal, maxVal]);
    % end
end