function scalarFieldViewer(x, y, z, f, scaleFactor)
    % Scalar field viewer with interactive point selection
    % Usage: scalarFieldViewer(x, y, z, @(x,y,z)f_func, scaleFactor)
    % x, y, z: arrays of coordinates (e.g., from meshgrid)
    % f: function handle that takes (x,y,z) and returns scalar value
    % scaleFactor: optional scaling for sphere radii (default: auto)

    % Developed by Isaac Pincus, 2025
    
    if nargin < 5
        scaleFactor = [];  % Will be computed automatically
    end
    
    % Create figure
    fig = figure('Name', 'Scalar Field Viewer', ...
                 'Position', [100 100 800 700]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.13 0.35 0.75 0.6]);
    hold(ax, 'on');
    grid(ax, 'on');
    title(ax, 'Scalar Field', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [49.56 19.67]);
    
    % Evaluate scalar field on grid
    F = f(x, y, z);
    
    % Auto-compute scale factor if not provided
    if isempty(scaleFactor)
        gridSpacing = min([abs(x(2,1,1) - x(1,1,1)), ...
                          abs(y(1,2,1) - y(1,1,1)), ...
                          abs(z(1,1,2) - z(1,1,1))]);
        maxF = max(abs(F(:)));
        if maxF > 0
            scaleFactor = 0.3 * gridSpacing / maxF;
        else
            scaleFactor = 0.3 * gridSpacing;
        end
    end
    
    % Generate unit sphere for plotting
    [xs, ys, zs] = sphere(8);
    
    % Plot scalar field as spheres
    for i = 1:numel(x)
        r = abs(F(i)) * scaleFactor;
        if r > 0.001  % Only plot if radius is significant
            surf(ax, xs*r + x(i), ys*r + y(i), zs*r + z(i), ...
                 'FaceColor', 'interp', 'EdgeColor', 'none', ...
                 'FaceAlpha', 0.5, 'CData', ones(size(xs))*F(i));
        end
    end
    
    colorbar(ax);
    
    % Initialize point position
    xLimits = [min(x(:)), max(x(:))];
    yLimits = [min(y(:)), max(y(:))];
    zLimits = [min(z(:)), max(z(:))];
    
    xPos = mean(xLimits);
    yPos = mean(yLimits);
    zPos = mean(zLimits);
    
    % Evaluate scalar at initial point
    fVal = f(xPos, yPos, zPos);
    
    % Create highlighted sphere for selected point
    r = abs(fVal) * scaleFactor;
    hSphere = surf(ax, xs*r + xPos, ys*r + yPos, zs*r + zPos, ...
                   'FaceColor', 'k', 'EdgeColor', 'none', ...
                   'FaceAlpha', 0.8, 'LineWidth', 2);
    
    % Create point marker at center
    hMarker = plot3(ax, xPos, yPos, zPos, 'ko', ...
                    'MarkerSize', 1, 'MarkerFaceColor', 'g', 'LineWidth', 0.1);
    
    % Create text label
    str = sprintf('$f(%.2f, %.2f, %.2f) = %.3f$', ...
                  xPos, yPos, zPos, fVal);
    hTxt = text(ax, xPos+0.3, yPos+0.3, zPos+0.3, str, ...
                'Interpreter', 'latex', 'FontSize', 12, ...
                'BackgroundColor', 'white', 'EdgeColor', 'black');
    
    % Add lighting
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    % Create x slider
    xSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.22 0.5 0.03], ...
                        'Min', xLimits(1), 'Max', xLimits(2), 'Value', xPos, ...
                        'Callback', @xSliderCallback);
    addlistener(xSlider, 'ContinuousValueChange', @(src,evt) xSliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.215 0.08 0.03], ...
              'String', 'x =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hXValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.76 0.215 0.1 0.03], ...
                        'String', sprintf('%.2f', xPos), 'FontSize', 11, ...
                        'HorizontalAlignment', 'left');
    
    % Create y slider
    ySlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.15 0.5 0.03], ...
                        'Min', yLimits(1), 'Max', yLimits(2), 'Value', yPos, ...
                        'Callback', @ySliderCallback);
    addlistener(ySlider, 'ContinuousValueChange', @(src,evt) ySliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.145 0.08 0.03], ...
              'String', 'y =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hYValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.76 0.145 0.1 0.03], ...
                        'String', sprintf('%.2f', yPos), 'FontSize', 11, ...
                        'HorizontalAlignment', 'left');
    
    % Create z slider
    zSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.08 0.5 0.03], ...
                        'Min', zLimits(1), 'Max', zLimits(2), 'Value', zPos, ...
                        'Callback', @zSliderCallback);
    addlistener(zSlider, 'ContinuousValueChange', @(src,evt) zSliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.075 0.08 0.03], ...
              'String', 'z =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hZValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.76 0.075 0.1 0.03], ...
                        'String', sprintf('%.2f', zPos), 'FontSize', 11, ...
                        'HorizontalAlignment', 'left');
    
    % Slider callback functions
    function xSliderCallback(src, ~)
        xPos = src.Value;
        set(hXValue, 'String', sprintf('%.2f', xPos));
        updatePlot();
    end
    
    function ySliderCallback(src, ~)
        yPos = src.Value;
        set(hYValue, 'String', sprintf('%.2f', yPos));
        updatePlot();
    end
    
    function zSliderCallback(src, ~)
        zPos = src.Value;
        set(hZValue, 'String', sprintf('%.2f', zPos));
        updatePlot();
    end
    
    % Update plot function
    function updatePlot()
        % Evaluate scalar at current point
        fVal = f(xPos, yPos, zPos);
        r = abs(fVal) * scaleFactor;
        
        % Update sphere
        set(hSphere, 'XData', xs*r + xPos, ...
                     'YData', ys*r + yPos, ...
                     'ZData', zs*r + zPos);
        
        % Update marker
        set(hMarker, 'XData', xPos, 'YData', yPos, 'ZData', zPos);
        
        % Update text
        str = sprintf('$f(%.2f, %.2f, %.2f) = %.3f$', ...
                      xPos, yPos, zPos, fVal);
        set(hTxt, 'String', str, 'Position', [xPos+0.3, yPos+0.3, zPos+0.3]);
    end
end