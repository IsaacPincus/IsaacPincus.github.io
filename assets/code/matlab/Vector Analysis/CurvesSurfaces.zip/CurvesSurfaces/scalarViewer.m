function scalarViewer(s_in)
    % scalarViewer - Visualizes a scalar as a sphere with variable radius and color.
    %
    % Usage: scalarViewer()
    %    or: scalarViewer(initial_scalar_value)

    % Developed by Isaac Pincus, 2025
    
    % Define slider range
    S_MIN = -5;
    S_MAX = 5;
    maxVal = S_MAX;
    
    % Set initial scalar
    if nargin < 1
        s = 1.0;
    else
        s = s_in;
        % Clamp initial value to be within slider limits
        s = max(min(s, S_MAX), S_MIN);
    end
    
    % Create figure
    fig = figure('Name', 'Scalar Viewer', ...
                 'Position', [100 100 600 600]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.1 0.25 0.8 0.7]);
    hold(ax, 'on');
    grid(ax, 'on');
    axis(ax, 'equal');
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [45 30]);
    
    % Create standard sphere coordinates (once)
    [X, Y, Z] = sphere(30);
    
    % Initial sphere properties
    radius = abs(s);
    CData = s * ones(size(Z)); % Color data based on scalar 's'
    
    % Create sphere surface plot
    hSphere = surf(ax, X*radius, Y*radius, Z*radius, CData, ...
                   'EdgeColor', 'none', ...
                   'FaceAlpha', 0.8);
    
    % Create origin marker
    plot3(ax, 0, 0, 0, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
    
    % Set up colormap and color axis
    colormap(ax, 'parula'); % 
    clim(ax, [S_MIN, S_MAX]);
    hCbar = colorbar(ax);
    ylabel(hCbar, 'Scalar Value $s$', 'Interpreter', 'latex', 'FontSize', 12);
    
    % Create dynamic title
    hTitle = title(ax, sprintf('Scalar $s = %.3f$', s), ...
                   'Interpreter', 'latex', 'FontSize', 14);
    
    % Set initial axis limits
    % updateAxisLimits();
    xlim(ax, [-maxVal, maxVal]);
    ylim(ax, [-maxVal, maxVal]);
    zlim(ax, [-maxVal, maxVal]);
    
    % Add lighting
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    % Create scalar slider
    sSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                         'Units', 'normalized', ...
                         'Position', [0.25 0.10 0.5 0.03], ...
                         'Min', S_MIN, 'Max', S_MAX, 'Value', s, ...
                         'Callback', @sSliderCallback);
    % Add continuous listener
    addlistener(sSlider, 'ContinuousValueChange', @(src,evt) sSliderCallback(src, evt));
    
    % Slider 's' label
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.095 0.08 0.03], ...
              'String', 's =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    % Slider value text
    hSValue = uicontrol('Parent', fig, 'Style', 'text', ...
                         'Units', 'normalized', ...
                         'Position', [0.76 0.095 0.1 0.03], ...
                         'String', sprintf('%.2f', s), 'FontSize', 11, ...
                         'HorizontalAlignment', 'left');

    % --- Nested Functions ---
    
    % Slider callback
    function sSliderCallback(src, ~)
        s = src.Value; % Get new scalar value
        set(hSValue, 'String', sprintf('%.2f', s));
        updatePlot();
    end
    
    % Main update function
    function updatePlot()
        % Calculate new properties
        radius = abs(s);
        CData = s * ones(size(Z)); % Update color data
        
        % Update sphere data efficiently
        set(hSphere, 'XData', X*radius, ...
                      'YData', Y*radius, ...
                      'ZData', Z*radius, ...
                      'CData', CData);
        
        % Update title
        set(hTitle, 'String', sprintf('Scalar $s = %.3f$', s));
        
        % % Update axis limits
        % updateAxisLimits();
    end
    
    % % Update axis limits based on scalar
    % function updateAxisLimits()
    %     % Keep a minimum axis size, but expand if radius is large
    %     maxVal = max([abs(s), 1.0]) * 1.5; 
    %     xlim(ax, [-maxVal, maxVal]);
    %     ylim(ax, [-maxVal, maxVal]);
    %     zlim(ax, [-maxVal, maxVal]);
    % end
end