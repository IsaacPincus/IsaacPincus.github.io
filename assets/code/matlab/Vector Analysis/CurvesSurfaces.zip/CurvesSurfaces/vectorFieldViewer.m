function vectorFieldViewer(x, y, z, vx, vy, vz)
    % Vector field viewer with interactive point selection
    % Usage: vectorFieldViewer(x, y, z, @(x,y,z)vx_func, @(x,y,z)vy_func, @(x,y,z)vz_func)
    % x, y, z: arrays of coordinates (e.g., from meshgrid)
    % vx, vy, vz: function handles that take (x,y,z) and return vector components

    % Developed by Isaac Pincus, 2025
    
    % Create figure
    fig = figure('Name', 'Vector Field Viewer', ...
                 'Position', [100 100 800 700]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.13 0.35 0.75 0.6]);
    hold(ax, 'on');
    grid(ax, 'on');
    title(ax, 'Vector Field', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [49.56 19.67]);
    
    % Evaluate vector field on grid
    VX = vx(x, y, z);
    VY = vy(x, y, z);
    VZ = vz(x, y, z);
    
    % Plot vector field in blue
    quiver3(ax, x, y, z, VX, VY, VZ, 0.5, 'b', 'LineWidth', 1);
    
    % Initialize point position
    xLimits = [min(x(:)), max(x(:))];
    yLimits = [min(y(:)), max(y(:))];
    zLimits = [min(z(:)), max(z(:))];
    
    xPos = mean(xLimits);
    yPos = mean(yLimits);
    zPos = mean(zLimits);
    
    % Evaluate vector at initial point
    vxVal = vx(xPos, yPos, zPos);
    vyVal = vy(xPos, yPos, zPos);
    vzVal = vz(xPos, yPos, zPos);
    
    % Create green quiver for selected point
    hPoint = quiver3(ax, xPos, yPos, zPos, vxVal, vyVal, vzVal, 0, ...
                     'LineWidth', 3, 'Color', 'g', 'MaxHeadSize', 0.5);
    
    % Create point marker
    hMarker = plot3(ax, xPos, yPos, zPos, 'go', ...
                    'MarkerSize', 10, 'MarkerFaceColor', 'g');
    
    % Create text label
    str = sprintf('$\\mathbf{v}(%.2f, %.2f, %.2f) = (%.2f, %.2f, %.2f)$', ...
                  xPos, yPos, zPos, vxVal, vyVal, vzVal);
    hTxt = text(ax, xPos+0.3, yPos+0.3, zPos+0.3, str, ...
                'Interpreter', 'latex', 'FontSize', 12, ...
                'BackgroundColor', 'white', 'EdgeColor', 'black');
    
    % Create x slider
    xSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.22 0.5 0.03], ...
                        'Min', xLimits(1), 'Max', xLimits(2), 'Value', xPos, ...
                        'Callback', @xSliderCallback);
    addlistener(xSlider, 'ContinuousValueChange', @(src,evt) xSliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.215 0.08 0.03], ...
              'String', 'x =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hXValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.76 0.215 0.1 0.03], ...
                        'String', sprintf('%.2f', xPos), 'FontSize', 11, ...
                        'HorizontalAlignment', 'left');
    
    % Create y slider
    ySlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.15 0.5 0.03], ...
                        'Min', yLimits(1), 'Max', yLimits(2), 'Value', yPos, ...
                        'Callback', @ySliderCallback);
    addlistener(ySlider, 'ContinuousValueChange', @(src,evt) ySliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.145 0.08 0.03], ...
              'String', 'y =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hYValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.76 0.145 0.1 0.03], ...
                        'String', sprintf('%.2f', yPos), 'FontSize', 11, ...
                        'HorizontalAlignment', 'left');
    
    % Create z slider
    zSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.08 0.5 0.03], ...
                        'Min', zLimits(1), 'Max', zLimits(2), 'Value', zPos, ...
                        'Callback', @zSliderCallback);
    addlistener(zSlider, 'ContinuousValueChange', @(src,evt) zSliderCallback(src, evt));
    
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.075 0.08 0.03], ...
              'String', 'z =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
    
    hZValue = uicontrol('Parent', fig, 'Style', 'text', ...
                        'Units', 'normalized', ...
                        'Position', [0.76 0.075 0.1 0.03], ...
                        'String', sprintf('%.2f', zPos), 'FontSize', 11, ...
                        'HorizontalAlignment', 'left');
    
    % Slider callback functions
    function xSliderCallback(src, ~)
        xPos = src.Value;
        set(hXValue, 'String', sprintf('%.2f', xPos));
        updatePlot();
    end
    
    function ySliderCallback(src, ~)
        yPos = src.Value;
        set(hYValue, 'String', sprintf('%.2f', yPos));
        updatePlot();
    end
    
    function zSliderCallback(src, ~)
        zPos = src.Value;
        set(hZValue, 'String', sprintf('%.2f', zPos));
        updatePlot();
    end
    
    % Update plot function
    function updatePlot()
        % Evaluate vector at current point
        vxVal = vx(xPos, yPos, zPos);
        vyVal = vy(xPos, yPos, zPos);
        vzVal = vz(xPos, yPos, zPos);
        
        % Update quiver
        set(hPoint, 'XData', xPos, 'YData', yPos, 'ZData', zPos, ...
                    'UData', vxVal, 'VData', vyVal, 'WData', vzVal);
        
        % Update marker
        set(hMarker, 'XData', xPos, 'YData', yPos, 'ZData', zPos);
        
        % Update text
        str = sprintf('$\\mathbf{v}(%.2f, %.2f, %.2f) = (%.2f, %.2f, %.2f)$', ...
                      xPos, yPos, zPos, vxVal, vyVal, vzVal);
        set(hTxt, 'String', str, 'Position', [xPos+0.3, yPos+0.3, zPos+0.3]);
    end
end