function tensorViewer(T)
    % Visualize a 3x3 tensor as three planes with vectors
    % Usage: tensorViewer(T)
    % T: 3x3 matrix representing the tensor
    %    Row 1: vector on yz-plane (perpendicular to x-axis)
    %    Row 2: vector on xz-plane (perpendicular to y-axis)
    %    Row 3: vector on xy-plane (perpendicular to z-axis)

    % Developed by Isaac Pincus, 2025
    
    if ~isequal(size(T), [3, 3])
        error('Input must be a 3x3 matrix');
    end
    
    % Create figure
    fig = figure('Name', 'Tensor Visualization', ...
                 'Position', [100 100 800 700]);
    
    ax = axes('Parent', fig);
    hold(ax, 'on');
    grid(ax, 'on');
    axis(ax, 'equal');
    title(ax, 'Tensor Visualization', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [45, 30]);
    
    % Define plane corners
    % YZ-plane (perpendicular to x-axis) at x = 0
    yzPlane = [0, 0, 0; 0, 1, 0; 0, 1, 1; 0, 0, 1];
    
    % XZ-plane (perpendicular to y-axis) at y = 0
    xzPlane = [0, 0, 0; 1, 0, 0; 1, 0, 1; 0, 0, 1];
    
    % XY-plane (perpendicular to z-axis) at z = 0
    xyPlane = [0, 0, 0; 1, 0, 0; 1, 1, 0; 0, 1, 0];
    
    % Plot YZ-plane (red)
    patch(ax, 'XData', yzPlane(:,1), 'YData', yzPlane(:,2), 'ZData', yzPlane(:,3), ...
          'FaceColor', 'r', 'FaceAlpha', 0.3, 'EdgeColor', 'r', 'LineWidth', 2);
    
    % Plot XZ-plane (green)
    patch(ax, 'XData', xzPlane(:,1), 'YData', xzPlane(:,2), 'ZData', xzPlane(:,3), ...
          'FaceColor', 'g', 'FaceAlpha', 0.3, 'EdgeColor', 'g', 'LineWidth', 2);
    
    % Plot XY-plane (blue)
    patch(ax, 'XData', xyPlane(:,1), 'YData', xyPlane(:,2), 'ZData', xyPlane(:,3), ...
          'FaceColor', 'b', 'FaceAlpha', 0.3, 'EdgeColor', 'b', 'LineWidth', 2);
    
    % Center of each plane
    yzCenter = [0, 0.5, 0.5];
    xzCenter = [0.5, 0, 0.5];
    xyCenter = [0.5, 0.5, 0];
    
    % Extract rows from tensor
    v1 = T(1, :);  % Vector on YZ-plane
    v2 = T(2, :);  % Vector on XZ-plane
    v3 = T(3, :);  % Vector on XY-plane
    
    % Plot vectors
    quiver3(ax, yzCenter(1), yzCenter(2), yzCenter(3), ...
            v1(1), v1(2), v1(3), 0, ...
            'LineWidth', 3, 'Color', 'r', 'MaxHeadSize', 0.5);
    
    quiver3(ax, xzCenter(1), xzCenter(2), xzCenter(3), ...
            v2(1), v2(2), v2(3), 0, ...
            'LineWidth', 3, 'Color', 'g', 'MaxHeadSize', 0.5);
    
    quiver3(ax, xyCenter(1), xyCenter(2), xyCenter(3), ...
            v3(1), v3(2), v3(3), 0, ...
            'LineWidth', 3, 'Color', 'b', 'MaxHeadSize', 0.5);
    
    % Add text labels
    text(ax, yzCenter(1)-0.2, yzCenter(2), yzCenter(3), ...
         sprintf('YZ: (%.2f, %.2f, %.2f)', v1(1), v1(2), v1(3)), ...
         'FontSize', 10, 'Color', 'r', 'FontWeight', 'bold');
    
    text(ax, xzCenter(1), xzCenter(2)-0.2, xzCenter(3), ...
         sprintf('XZ: (%.2f, %.2f, %.2f)', v2(1), v2(2), v2(3)), ...
         'FontSize', 10, 'Color', 'g', 'FontWeight', 'bold');
    
    text(ax, xyCenter(1), xyCenter(2), xyCenter(3)-0.2, ...
         sprintf('XY: (%.2f, %.2f, %.2f)', v3(1), v3(2), v3(3)), ...
         'FontSize', 10, 'Color', 'b', 'FontWeight', 'bold');
    
    % % Add tensor matrix display
    % tensorStr = sprintf('$$\\mathbf{T} = \\begin{bmatrix} %.2f & %.2f & %.2f \\\\ %.2f & %.2f & %.2f \\\\ %.2f & %.2f & %.2f \\end{bmatrix}$$', ...
    %                     T(1,1), T(1,2), T(1,3), T(2,1), T(2,2), T(2,3), T(3,1), T(3,2), T(3,3));
    % 
    % annotation('textbox', [0.15, 0.85, 0.7, 0.1], ...
    %            'String', tensorStr, ...
    %            'Interpreter', 'latex', ...
    %            'FontSize', 14, ...
    %            'EdgeColor', 'none', ...
    %            'HorizontalAlignment', 'center');
    
    % Set axis limits
    xlim(ax, [-0.5, 1.5]);
    ylim(ax, [-0.5, 1.5]);
    zlim(ax, [-0.5, 1.5]);
    
    % Add lighting for better 3D effect
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    hold(ax, 'off');
end