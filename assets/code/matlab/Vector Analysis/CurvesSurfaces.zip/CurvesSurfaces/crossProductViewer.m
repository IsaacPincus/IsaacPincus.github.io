function crossProductViewer(u_in, v_in)
    % crossProductViewer - Visualizes two vectors u, v and their cross product w = u x v.
    %
    % Usage: crossProductViewer()
    %    or: crossProductViewer([ux, uy, uz], [vx, vy, vz])

    % Developed by Isaac Pincus, 2025
    
    % --- 1. Set Initial Vectors ---
    
    % Define slider range
    SLIDER_MIN = -5;
    SLIDER_MAX = 5;
    
    if nargin < 2
        % Default: u = (1, 1, 0), v = (0, 1, 1)
        ux = 1; uy = 1; uz = 0;
        vx = 0; vy = 1; vz = 1;
    else
        ux = u_in(1); uy = u_in(2); uz = u_in(3);
        vx = v_in(1); vy = v_in(2); vz = v_in(3);
    end
    
    % Calculate initial cross product
    u = [ux, uy, uz];
    v = [vx, vy, vz];
    w = cross(u, v);
    wx = w(1); wy = w(2); wz = w(3);
    
    % --- 2. Create Figure and Axes ---
    fig = figure('Name', 'Cross Product Viewer', ...
                 'Position', [100 100 700 800]); % Taller figure for 6 sliders
    
    ax = axes('Parent', fig, 'Position', [0.13 0.40 0.75 0.55]);
    hold(ax, 'on');
    grid(ax, 'on');
    axis(ax, 'equal');
    title(ax, 'Cross Product Visualization: $\mathbf{w} = \mathbf{u} \times \mathbf{v}$', ...
          'Interpreter', 'latex', 'FontSize', 14);
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [135 25]);
    
    % --- 3. Create Plot Objects ---
    
    % Vector u (blue)
    hU = quiver3(ax, 0, 0, 0, ux, uy, uz, 0, ...
                   'LineWidth', 2, 'Color', 'b', 'MaxHeadSize', 0.5);
    
    % Vector v (red)
    hV = quiver3(ax, 0, 0, 0, vx, vy, vz, 0, ...
                   'LineWidth', 2, 'Color', 'r', 'MaxHeadSize', 0.5);
                   
    % Vector w = u x v (magenta)
    hW = quiver3(ax, 0, 0, 0, wx, wy, wz, 0, ...
                   'LineWidth', 3, 'Color', 'm', 'MaxHeadSize', 0.5, ...
                   'LineStyle', '--');
    
    % Origin marker
    plot3(ax, 0, 0, 0, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
    
    % --- 4. Create Text Labels ---
    
    % Text for u
    strU = sprintf('$\\mathbf{u} = (%.2f, %.2f, %.2f)$', ux, uy, uz);
    magU = sprintf('$|\\mathbf{u}| = %.3f$', norm(u));
    hTxtU = text(ax, ux*1.1, uy*1.1, uz*1.1, {strU, magU}, ...
                'Interpreter', 'latex', 'FontSize', 12, ...
                'BackgroundColor', [0.9 0.9 1], 'EdgeColor', 'b');
    
    % Text for v
    strV = sprintf('$\\mathbf{v} = (%.2f, %.2f, %.2f)$', vx, vy, vz);
    magV = sprintf('$|\\mathbf{v}| = %.3f$', norm(v));
    hTxtV = text(ax, vx*1.1, vy*1.1, vz*1.1, {strV, magV}, ...
                'Interpreter', 'latex', 'FontSize', 12, ...
                'BackgroundColor', [1 0.9 0.9], 'EdgeColor', 'r');
                
    % Text for w
    strW = sprintf('$\\mathbf{w} = (%.2f, %.2f, %.2f)$', wx, wy, wz);
    magW = sprintf('$|\\mathbf{w}| = %.3f$', norm(w));
    hTxtW = text(ax, wx*1.1, wy*1.1, wz*1.1, {strW, magW}, ...
                'Interpreter', 'latex', 'FontSize', 12, ...
                'BackgroundColor', [1 0.9 1], 'EdgeColor', 'm');
    
    % Add legend
    legend([hU, hV, hW], {'$\mathbf{u}$', '$\mathbf{v}$', '$\mathbf{w} = \mathbf{u} \times \mathbf{v}$'}, ...
           'Interpreter', 'latex', 'FontSize', 11);
           
    % Set initial axis limits
    updateAxisLimits();
    
    % Add lighting
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    % --- 5. Create Sliders ---
    
    % --- Vector u Sliders ---
    y_pos = 0.30; % Starting Y position for sliders
    
    % ux slider
    makeSlider('ux', [0.25 y_pos 0.5 0.03], ux, @uxSliderCallback);
    hUxValue = makeLabel('ux =', [0.13 y_pos-0.0025 0.1 0.03], ...
                         [0.76 y_pos-0.0025 0.1 0.03], ux);
    y_pos = y_pos - 0.04;
    
    % uy slider
    makeSlider('uy', [0.25 y_pos 0.5 0.03], uy, @uySliderCallback);
    hUyValue = makeLabel('uy =', [0.13 y_pos-0.0025 0.1 0.03], ...
                         [0.76 y_pos-0.0025 0.1 0.03], uy);
    y_pos = y_pos - 0.04;
    
    % uz slider
    makeSlider('uz', [0.25 y_pos 0.5 0.03], uz, @uzSliderCallback);
    hUzValue = makeLabel('uz =', [0.13 y_pos-0.0025 0.1 0.03], ...
                         [0.76 y_pos-0.0025 0.1 0.03], uz);
    
    % --- Vector v Sliders ---
    y_pos = y_pos - 0.06; % Add a gap
    
    % vx slider
    makeSlider('vx', [0.25 y_pos 0.5 0.03], vx, @vxSliderCallback);
    hVxValue = makeLabel('vx =', [0.13 y_pos-0.0025 0.1 0.03], ...
                         [0.76 y_pos-0.0025 0.1 0.03], vx);
    y_pos = y_pos - 0.04;
    
    % vy slider
    makeSlider('vy', [0.25 y_pos 0.5 0.03], vy, @vySliderCallback);
    hVyValue = makeLabel('vy =', [0.13 y_pos-0.0025 0.1 0.03], ...
                         [0.76 y_pos-0.0025 0.1 0.03], vy);
    y_pos = y_pos - 0.04;
    
    % vz slider
    makeSlider('vz', [0.25 y_pos 0.5 0.03], vz, @vzSliderCallback);
    hVzValue = makeLabel('vz =', [0.13 y_pos-0.0025 0.1 0.03], ...
                         [0.76 y_pos-0.0025 0.1 0.03], vz);
    
    % --- 6. Nested Functions ---
    
    % Helper function to create sliders
    function makeSlider(~, pos, val, cb)
        slider = uicontrol('Parent', fig, 'Style', 'slider', ...
                         'Units', 'normalized', 'Position', pos, ...
                         'Min', SLIDER_MIN, 'Max', SLIDER_MAX, 'Value', val, ...
                         'Callback', cb);
        addlistener(slider, 'ContinuousValueChange', @(src,evt) cb(src, evt));
    end
    
    % Helper function to create labels
    function hValue = makeLabel(str, posStr, posVal, val)
        uicontrol('Parent', fig, 'Style', 'text', 'Units', 'normalized', ...
                  'Position', posStr, 'String', str, 'FontSize', 11, ...
                  'HorizontalAlignment', 'right');
        hValue = uicontrol('Parent', fig, 'Style', 'text', 'Units', 'normalized', ...
                           'Position', posVal, 'String', sprintf('%.2f', val), ...
                           'FontSize', 11, 'HorizontalAlignment', 'left');
    end

    % --- Slider Callbacks ---
    function uxSliderCallback(src, ~)
        ux = src.Value;
        set(hUxValue, 'String', sprintf('%.2f', ux));
        updatePlot();
    end
    
    function uySliderCallback(src, ~)
        uy = src.Value;
        set(hUyValue, 'String', sprintf('%.2f', uy));
        updatePlot();
    end
    
    function uzSliderCallback(src, ~)
        uz = src.Value;
        set(hUzValue, 'String', sprintf('%.2f', uz));
        updatePlot();
    end
    
    function vxSliderCallback(src, ~)
        vx = src.Value;
        set(hVxValue, 'String', sprintf('%.2f', vx));
        updatePlot();
    end
    
    function vySliderCallback(src, ~)
        vy = src.Value;
        set(hVyValue, 'String', sprintf('%.2f', vy));
        updatePlot();
    end
    
    function vzSliderCallback(src, ~)
        vz = src.Value;
        set(hVzValue, 'String', sprintf('%.2f', vz));
        updatePlot();
    end
    
    % --- Main Update Functions ---
    
    % Update plot function
    function updatePlot()
        % Rebuild vectors
        u = [ux, uy, uz];
        v = [vx, vy, vz];
        
        % Recalculate cross product
        w = cross(u, v);
        wx = w(1); wy = w(2); wz = w(3);
        
        % Update vector u
        set(hU, 'UData', ux, 'VData', uy, 'WData', uz);
        strU = sprintf('$\\mathbf{u} = (%.2f, %.2f, %.2f)$', ux, uy, uz);
        magU = sprintf('$|\\mathbf{u}| = %.3f$', norm(u));
        set(hTxtU, 'String', {strU, magU}, ...
                   'Position', [ux*1.1, uy*1.1, uz*1.1]);
        
        % Update vector v
        set(hV, 'UData', vx, 'VData', vy, 'WData', vz);
        strV = sprintf('$\\mathbf{v} = (%.2f, %.2f, %.2f)$', vx, vy, vz);
        magV = sprintf('$|\\mathbf{v}| = %.3f$', norm(v));
        set(hTxtV, 'String', {strV, magV}, ...
                   'Position', [vx*1.1, vy*1.1, vz*1.1]);
                   
        % Update vector w
        set(hW, 'UData', wx, 'VData', wy, 'WData', wz);
        strW = sprintf('$\\mathbf{w} = (%.2f, %.2f, %.2f)$', wx, wy, wz);
        magW = sprintf('$|\\mathbf{w}| = %.3f$', norm(w));
        set(hTxtW, 'String', {strW, magW}, ...
                   'Position', [wx*1.1, wy*1.1, wz*1.1]);
        
        % Update axis limits
        updateAxisLimits();
    end
    
    % Update axis limits based on all vectors
    function updateAxisLimits()
        % Find the max component of all 3 vectors
        maxComp = max(abs([ux, uy, uz, vx, vy, vz, wx, wy, wz, 1]));
        
        % Set new limit
        lim = maxComp * 1.5; % 50% buffer
        
        xlim(ax, [-lim, lim]);
        ylim(ax, [-lim, lim]);
        zlim(ax, [-lim, lim]);
    end
end