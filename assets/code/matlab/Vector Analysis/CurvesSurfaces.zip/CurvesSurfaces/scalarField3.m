function scalarField3(x, y, z, values, scaleFactor)
    % scalarField3 - visualize scalar field with spheres
    % x, y, z: coordinates (can be vectors or grids)
    % values: scalar values at each point
    % scaleFactor: optional scaling for sphere radii

    % Developed by Isaac Pincus, 2025
    
    if nargin < 5
        scaleFactor = 1;
    end
    
    % Generate unit sphere
    [xs, ys, zs] = sphere(8);
    
    hold on;
    for i = 1:length(x(:))
        r = abs(values(i)) * scaleFactor;
        % Plot sphere centered at (x(i), y(i), z(i)) with radius r
        surf(xs*r + x(i), ys*r + y(i), zs*r + z(i), ...
             'FaceColor', 'interp', 'EdgeColor', 'none', ...
             'FaceAlpha', 0.6, 'CData', ones(size(xs))*values(i));
    end
    % colorbar;
    hold off;
end