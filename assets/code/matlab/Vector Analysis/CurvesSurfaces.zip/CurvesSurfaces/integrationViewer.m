function integrationViewer(fxy, x0, x1, y0, y1, A)
    % Interactive integration visualizer with moving slice
    % Usage: integrationViewer(@(x,y)func, x0, x1, y0, y1)
    %    or: integrationViewer(@(x,y)func, x0, x1, y0, y1, @(y)area_func)
    % x0, x1: can be constants or function handles of y (e.g., @(y)y^2)
    % A: optional function of y representing the area of the slice

    % Developed by Isaac Pincus, 2025
    
    if nargin < 6
        A = [];
        showArea = false;
    else
        showArea = true;
    end
    
    % Check if x0 and x1 are functions or constants
    if isa(x0, 'function_handle')
        x0_func = x0;
        x0_is_func = true;
    else
        x0_func = @(y) x0;
        x0_is_func = false;
    end
    
    if isa(x1, 'function_handle')
        x1_func = x1;
        x1_is_func = true;
    else
        x1_func = @(y) x1;
        x1_is_func = false;
    end
    
    % Create grid - if x limits are functions, create custom grid
    y = linspace(y0, y1, 100);
    
    if x0_is_func || x1_is_func
        % Variable domain - create grid point by point
        X = [];
        Y = [];
        Z = [];
        for i = 1:length(y)
            x_row = linspace(x0_func(y(i)), x1_func(y(i)), 100);
            X = [X; x_row];
            Y = [Y; ones(size(x_row))*y(i)];
            Z = [Z; fxy(x_row, y(i))];
        end
    else
        % Constant domain - use regular meshgrid
        x = linspace(x0, x1, 100);
        [X, Y] = meshgrid(x, y);
        Z = fxy(X, Y);
    end
    
    % Create figure
    fig = figure('Name', 'Integration Visualizer', ...
                 'Position', [100 100 800 700]);
    
    % Create axes
    ax = axes('Parent', fig, 'Position', [0.13 0.25 0.75 0.7]);
    hold(ax, 'on');
    box(ax, 'on');
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 20);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 20);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 20);
    view(ax, [-30, 30]);
    
    % Plot surface
    surf(ax, X, Y, Z, 'FaceAlpha', 0.7, 'EdgeColor', 'none');
    
    % Plot base plane
    surf(ax, X, Y, zeros(size(Z)), 'FaceAlpha', 0.2, ...
         'EdgeColor', 'none', 'FaceColor', 'k');
    
    % Set axis limits
    if x0_is_func || x1_is_func
        xlim(ax, [min(X(:)), max(X(:))]);
    else
        xlim(ax, [x0, x1]);
    end
    ylim(ax, [y0, y1]);
    
    % Initial slice position
    ySlice = (y0 + y1) / 2;
    
    % Create initial patch
    x0_val = x0_func(ySlice);
    x1_val = x1_func(ySlice);
    xv = linspace(x0_val, x1_val, 50);
    zv = fxy(xv, ySlice);
    xp = [xv(1), xv, xv(end)]';
    yp = ones(size(xp)) * ySlice;
    zp = [0, zv, 0]';
    
    hPatch = patch(ax, xp, yp, zp, 'r', 'FaceAlpha', 0.6, 'EdgeColor', 'k', 'LineWidth', 1.5);
    
    % Add text label for slice position
    zMax = max(Z(:));
    xText = x0_func(y0) + 0.1*(x1_func(y1) - x0_func(y0));
    hText = text(ax, xText, ySlice, zMax*1.1, ...
                 sprintf('y = %.2f', ySlice), ...
                 'FontSize', 14, 'FontWeight', 'bold', ...
                 'BackgroundColor', 'white', 'EdgeColor', 'black');
    
    % Add text label for area if provided
    if showArea
        areaVal = A(ySlice);
        hAreaText = text(ax, xText, ySlice, zMax*1.25, ...
                         sprintf('A(y) = %.3f', areaVal), ...
                         'FontSize', 14, 'FontWeight', 'bold', ...
                         'BackgroundColor', 'yellow', 'EdgeColor', 'black');
    end
    
    % Add lighting
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    % Create slider
    ySlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                        'Units', 'normalized', ...
                        'Position', [0.25 0.1 0.5 0.04], ...
                        'Min', y0, 'Max', y1, 'Value', ySlice, ...
                        'Callback', @sliderCallback);
    
    % Add listener for continuous update
    addlistener(ySlider, 'ContinuousValueChange', @(src,evt) sliderCallback(src, evt));
    
    % Slider label
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.15 0.095 0.08 0.04], ...
              'String', 'y =', 'FontSize', 12, ...
              'HorizontalAlignment', 'right');
    
    % Slider value display
    hSliderValue = uicontrol('Parent', fig, 'Style', 'text', ...
                             'Units', 'normalized', ...
                             'Position', [0.76 0.095 0.1 0.04], ...
                             'String', sprintf('%.2f', ySlice), 'FontSize', 12, ...
                             'HorizontalAlignment', 'left');
    
    % Slider callback
    function sliderCallback(src, ~)
        ySlice = src.Value;
        
        % Update patch with new x limits at this y
        x0_val = x0_func(ySlice);
        x1_val = x1_func(ySlice);
        xv = linspace(x0_val, x1_val, 50);
        zv = fxy(xv, ySlice);
        xp = [xv(1), xv, xv(end)]';
        yp = ones(size(xp)) * ySlice;
        zp = [0, zv, 0]';
        
        set(hPatch, 'XData', xp, 'YData', yp, 'ZData', zp);
        
        % Update text
        xText = x0_val + 0.1*(x1_val - x0_val);
        set(hText, 'Position', [xText, ySlice, zMax*1.1], ...
                   'String', sprintf('y = %.2f', ySlice));
        
        % Update area text if provided
        if showArea
            areaVal = A(ySlice);
            set(hAreaText, 'Position', [xText, ySlice, zMax*1.25], ...
                           'String', sprintf('A(y) = %.3f', areaVal));
        end
        
        % Update slider value display
        set(hSliderValue, 'String', sprintf('%.2f', ySlice));
    end
end