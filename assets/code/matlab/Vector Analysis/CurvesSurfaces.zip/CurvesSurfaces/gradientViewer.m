function gradientViewer(f, gfx, gfy, gfz)
    % gradientViewer - Visualizes a scalar field and its (optional) gradient.
    %
    % Usage:
    %   1. Scalar field only:
    %      f = @(x,y,z) x.^2 + y.^2 + z.^2;
    %      gradientViewer(f);
    %
    %   2. Scalar field and analytical gradient:
    %      f = @(x,y,z) x.^2 - y.^2 - z;
    %      gfx = @(x,y,z) 2*x;
    %      gfy = @(x,y,z) -2*y;
    %      gfz = @(x,y,z) -1 + 0*x; % 0*x ensures correct array size
    %      gradientViewer(f, gfx, gfy, gfz);

    % Developed by Isaac Pincus, 2025
    
    % --- 1. Configuration ---
    
    % Check if gradient is provided
    hasGradient = (nargin == 4);
    
    % Define the 3D grid for evaluation
    DOMAIN_MIN = -2.5;
    DOMAIN_MAX = 2.5;
    GRID_POINTS = 35; % 35x35x35 grid. Higher is smoother, lower is faster.
    
    % Quiver plot downsampling (plot 1 arrow every 'skip' points)
    QUIVER_SKIP = 6;
    
    % --- 2. Setup Figure and Axes ---
    fig = figure('Name', 'Gradient Viewer', 'Position', [100 100 700 700]);
    ax = axes('Parent', fig, 'Position', [0.1, 0.2, 0.8, 0.7]);
    
    hold(ax, 'on');
    grid(ax, 'on');
    axis(ax, 'equal');
    
    xlabel(ax, '$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel(ax, '$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel(ax, '$z$', 'Interpreter', 'latex', 'FontSize', 12);
    view(ax, [135, 25]);
    camlight(ax, 'headlight');
    lighting(ax, 'gouraud');
    
    % Set static axis limits
    axis(ax, [DOMAIN_MIN, DOMAIN_MAX, DOMAIN_MIN, DOMAIN_MAX, DOMAIN_MIN, DOMAIN_MAX]);
    
    % --- 3. Evaluate Fields on the Grid ---
    
    % Create the grid
    [X, Y, Z] = meshgrid(linspace(DOMAIN_MIN, DOMAIN_MAX, GRID_POINTS));
    
    % Evaluate the scalar field (This is the slow part)
    fprintf('Evaluating scalar field f(x,y,z)...\n');
    F_values = f(X, Y, Z);
    fprintf('...done.\n');
    
    % Evaluate gradient field (if provided)
    U = []; V = []; W = [];
    if hasGradient
        fprintf('Evaluating gradient field...\n');
        U = gfx(X, Y, Z);
        V = gfy(X, Y, Z);
        W = gfz(X, Y, Z);
        fprintf('...done.\n');
    end

    % --- 4. Determine Slider Range ---
    f_min = min(F_values(:));
    f_max = max(F_values(:));
    
    % Handle cases where field is constant or invalid
    if isinf(f_min) || isinf(f_max) || isnan(f_min) || isnan(f_max)
         warning('Function returned Inf/NaN. Clamping range to -10, 10');
         f_min = -10; f_max = 10;
         F_values(isnan(F_values)) = f_min;
         F_values(isinf(F_values)) = f_max;
         F_values(isinf(-F_values)) = f_min;
    end
    if f_min == f_max
         f_min = f_min - 1;
         f_max = f_max + 1;
    end
    
    % Set initial isosurface value
    initial_fv = (f_min + f_max) / 2;

    % --- 5. Initial Plot ---
    
    % Get initial surface data
    [faces, verts] = isosurface(X, Y, Z, F_values, initial_fv);
    
    % Get color data (map to Z-coordinate)
    if isempty(verts)
        colors = [];
    else
        colors = initial_fv*ones(size(verts(:, 3))); % Color by fv
    end
    
    % Plot isosurface using a patch object (fast to update)
    hSurface = patch('Parent', ax, ...
                     'Faces', faces, ...
                     'Vertices', verts, ...
                     'FaceVertexCData', colors, ...
                     'FaceColor', 'interp', ...
                     'EdgeColor', 'none', ...
                     'FaceAlpha', 0.7);
                     
    % Add isonormals for correct lighting
    isonormals(X, Y, Z, F_values, hSurface);
    
    % Plot quiver (if provided)
    if hasGradient
        % Downsample indices
        idx = 1:QUIVER_SKIP:GRID_POINTS;
        
        quiver3(ax, X(idx, idx, idx), Y(idx, idx, idx), Z(idx, idx, idx), ...
                    U(idx, idx, idx), V(idx, idx, idx), W(idx, idx, idx), ...
                    0.5, 'r', 'LineWidth', 1); % 0.5 is scaling factor
    end
    
    % Set colormap and colorbar
    colormap(ax, 'parula');
    hCbar = colorbar(ax);
    clim(ax, [f_min, f_max]);
    ylabel(hCbar, 'fval', 'FontSize', 11);

    % --- 6. Create Slider and Title ---
    
    % Dynamic title
    hTitle = title(ax, sprintf('$f(x,y,z) = %.3f$', initial_fv), ...
                   'Interpreter', 'latex', 'FontSize', 14);

    % Isovalue slider
    fvSlider = uicontrol('Parent', fig, 'Style', 'slider', ...
                         'Units', 'normalized', ...
                         'Position', [0.25 0.05 0.5 0.03], ...
                         'Min', f_min, 'Max', f_max, 'Value', initial_fv, ...
                         'Callback', @sliderCallback);
    % Add continuous listener
    addlistener(fvSlider, 'ContinuousValueChange', @(src,evt) sliderCallback(src, evt));
    
    % Slider labels
    uicontrol('Parent', fig, 'Style', 'text', ...
              'Units', 'normalized', ...
              'Position', [0.13 0.045 0.1 0.03], ...
              'String', 'f(x,y,z) =', 'FontSize', 11, ...
              'HorizontalAlignment', 'right');
              
    hFvValue = uicontrol('Parent', fig, 'Style', 'text', ...
                          'Units', 'normalized', ...
                          'Position', [0.76 0.045 0.1 0.03], ...
                          'String', sprintf('%.2f', initial_fv), 'FontSize', 11, ...
                          'HorizontalAlignment', 'left');

    % --- 7. Nested Callback Function ---
    
    function sliderCallback(src, ~)
        % Get new isovalue from slider
        fv = src.Value;
        
        % Update text labels
        set(hFvValue, 'String', sprintf('%.2f', fv));
        set(hTitle, 'String', sprintf('$f(x,y,z) = %.3f$', fv));
        
        % Recalculate the isosurface (fast)
        [faces, verts] = isosurface(X, Y, Z, F_values, fv);
        
        % Get new color data
        if isempty(verts)
            colors = [];
        else
            colors = fv*ones(size(verts(:, 3))); % Color by fv
        end
        
        % Update the patch object's data (very fast)
        set(hSurface, 'Faces', faces, 'Vertices', verts, 'FaceVertexCData', colors);
        
        % Recalculate normals for the new surface
        isonormals(X, Y, Z, F_values, hSurface);
    end
end